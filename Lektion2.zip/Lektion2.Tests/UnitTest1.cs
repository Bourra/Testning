using System;
using Xunit;
using Lektion2;

namespace Lektion2.Tests
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {

        }
    }
}
